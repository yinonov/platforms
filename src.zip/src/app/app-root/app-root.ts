// src/app/app-root.ts
import { FASTElement } from "@microsoft/fast-element";
import { Router } from "@vaadin/router";
//import "../pages/contract-view";

const routes = [
  { path: "/", redirect: "/edit-contract" },
  {
    path: "/edit-contract",
    component: "edit-contract",
    action: async () => {
      await import("../pages/edit-contract");
      return;
    },
  },
  //{ path: "/contract-view", component: "contract-view" },
];
export class AppRoot extends FASTElement {
  connectedCallback() {
    super.connectedCallback();
    const router = new Router(this);
    router.setRoutes(routes);
  }
}
